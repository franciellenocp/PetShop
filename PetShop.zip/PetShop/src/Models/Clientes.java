package Models;
import java.util.ArrayList;
import java.util.List;

public class Clientes extends Pessoa {
    //Atributos
    private int id;
    private List <Animais> pet = new ArrayList<>();

    //Construtor

    public Clientes(int id, List<Animais> pet) {
        this.id = id;
        this.pet = pet;
    }
    public Clientes(){}

    //Metódos

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Animais> getPet() {
        return pet;
    }

    public void setPet(List<Animais> pet) {
        this.pet = pet;
    }

    @Override
    public String toString() {
        return "Clientes{" +
                "id=" + id +
                ", pet=" + pet +
                '}';
    }
}
