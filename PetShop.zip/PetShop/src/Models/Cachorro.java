package Models;

public class Cachorro extends Animais{
    public Cachorro(){}

}
