package Models;

public class Gato extends Animais {
    public Gato() {
    }
}
