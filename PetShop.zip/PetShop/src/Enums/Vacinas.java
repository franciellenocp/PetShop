package Enums;

public enum Vacinas {
    VACINA_1,
    VACINA_2,
    VACINA_3,
    VACINA_4,
    VACINA_5;
}
