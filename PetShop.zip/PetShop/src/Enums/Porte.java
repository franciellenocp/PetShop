package Enums;

public enum Porte {
    PEQUENO,
    MEDIO,
    GRANDE;
}
