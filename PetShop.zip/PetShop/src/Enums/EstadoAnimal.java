package Enums;

public enum EstadoAnimal {
    SUJO,
    NORMAL,
    LIMPO,
    LIMPO_E_TOSADO,
    TOSADO;
}
