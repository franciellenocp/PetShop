package Servicos;

import Enums.EstadoAnimal;
import Enums.Higiene;
import Enums.Servicos;
import Enums.Vacinas;
import Models.Animais;
import Models.Clientes;
import Models.Endereco;
import VO.ResponseVO;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

public class PetShop {
    //Atributos
    final int HIGIENIZAR = 1;
    final int ATENDIMENTO = 2;
    final int VACINA = 3;
    private String cnpj;
    private Endereco endereco;

    static List<Alimentos> alimentoList = criarListaAlimentos();
    static List<Remedio> remedioList = criarListaRemedios();

    //Metódos

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public static List<Remedio> criarListaRemedios() {
        Remedio remedio = new Remedio(1, "Gaviz", new BigDecimal("20"));
        Remedio remedio2 = new Remedio(2, "Dipirona", new BigDecimal("10"));
        Remedio remedio3 = new Remedio(3, "Floral", new BigDecimal("35"));
        Remedio remedio4 = new Remedio(4, "Vitamina", new BigDecimal("33"));
        return Arrays.asList(remedio, remedio2, remedio3, remedio4);

    }

    public static List<Alimentos> criarListaAlimentos() {
        Alimentos alimento = new Alimentos(1, "Ração Umida", new BigDecimal("10"));
        Alimentos alimento2 = new Alimentos(2, "Ração Seca", new BigDecimal("100"));
        Alimentos alimento3 = new Alimentos(3, "Biscoito", new BigDecimal("35"));
        Alimentos alimento4 = new Alimentos(4, "Ossinho", new BigDecimal("6"));
        return Arrays.asList(alimento, alimento2, alimento3, alimento4);

    }

    /**
     * ResponseVO higienizar(Cliente cliente, List<Animal> animais, Higiene higiene, String observacao);
     * Retornar o id do servico, o nome dele, o valor e a classe cliente
     */
    public ResponseVO higienizar(Clientes cliente, List<Animais> animais, Higiene higiene, String observacao) {
        ResponseVO response = new ResponseVO();
        if (higiene.equals(Higiene.BANHO)) {
            response.setValor(BigDecimal.valueOf(25));
            //Preencher o Status de mais de um animal, no array
            animais.get(0).setEstado(EstadoAnimal.LIMPO);
        } else if (higiene.equals(Higiene.TOSA)) {
            response.setValor(BigDecimal.valueOf(45));
            animais.get(0).setEstado(EstadoAnimal.TOSADO);
        } else if (higiene.equals(Higiene.BANHO_E_TOSA)) {
            response.setValor(BigDecimal.valueOf(65));
            animais.get(0).setEstado(EstadoAnimal.LIMPO_E_TOSADO);
        }
        BigDecimal x = new BigDecimal(animais.size());
        response.setValor(response.getValor().multiply(x));
        response.setId(HIGIENIZAR);
        response.setClientes(cliente);
        response.setServicos(Servicos.HIGIENIZAR);
        return response;
    }

    /**
     * ResponseVO atendimentoClinico(Cliente cliente, List<Animal> animais, String observacao);
     * retornar resultado do atendimento no campo Observação do próprio animal além do id do servico, o nome dele, o valor e a classe cliente
     */
    public ResponseVO atendimentoClinico(Clientes cliente, List<Animais> animais, String observacao) {
        ResponseVO response = new ResponseVO();
        if (observacao.equalsIgnoreCase("VACINA")) {
            animais.get(0).setObservacoes("TOMARA VACINA_2");
            animais.get(0).setEstado(EstadoAnimal.NORMAL);
        }
        response.setId(ATENDIMENTO);
        response.setClientes(cliente);
        response.setValor(BigDecimal.valueOf(110));
        response.setServicos(Servicos.ATENDIMENTO_CLINICO);
        return response;
    }

    /**
     * ResponseVO vacinacao(Cliente cliente, List<Animal> animais, List<Vacinas> vacina, String observacao)
     * Só pode receber uma vacina por animal e deve retornar o id do servico, o nome dele, o valor e a classe cliente
     */
    public ResponseVO vacinacao(Clientes cliente, List<Animais> animais, List<Vacinas> vacinas, String observacao) {
        ResponseVO response = new ResponseVO();
        //Criar esquema de vacinação
        response.setId(VACINA);
        response.setClientes(cliente);
        response.setValor(BigDecimal.valueOf(40));
        response.setServicos(Servicos.VACINACAO);
        animais.get(0).setEstado(EstadoAnimal.NORMAL);
        animais.get(0).getVacinas();
        return response;
    }

    public void verAlimentos() {
        alimentoList.forEach(alimentos -> System.out.println(alimentos));
    }

    public void verRemedios() {
        remedioList.forEach(remedio -> System.out.println(remedio));
    }

    void pagamento() {
        
//        System.out.println(Pagamento.toString());
    }


}