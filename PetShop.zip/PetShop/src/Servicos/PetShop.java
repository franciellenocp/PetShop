package Servicos;

import Enums.EstadoAnimal;
import Enums.Higiene;
import Enums.Servicos;
import Enums.Vacinas;
import Models.Animais;
import Models.Clientes;
import Models.Endereco;
import VO.ResponseVO;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class PetShop {
    //Atributos
    final int HIGIENIZAR = 1;
    final int ATENDIMENTO = 2;
    final int VACINA = 3;
    private String cnpj;
    private Endereco endereco;

    static List<Alimentos> alimentoList = criarListaAlimentos();
    static List<Remedio> remedioList = criarListaRemedios();

    //Metódos

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public static List<Remedio> criarListaRemedios() {
        Remedio remedio = new Remedio(1, "Gaviz", new BigDecimal("20"));
        Remedio remedio2 = new Remedio(2, "Dipirona", new BigDecimal("10"));
        Remedio remedio3 = new Remedio(3, "Floral", new BigDecimal("35"));
        Remedio remedio4 = new Remedio(4, "Vitamina", new BigDecimal("33"));
        return Arrays.asList(remedio, remedio2, remedio3, remedio4);

    }

    public static List<Alimentos> criarListaAlimentos() {
        Alimentos alimento = new Alimentos(1, "Ração Umida", new BigDecimal("10"));
        Alimentos alimento2 = new Alimentos(2, "Ração Seca", new BigDecimal("100"));
        Alimentos alimento3 = new Alimentos(3, "Biscoito", new BigDecimal("35"));
        Alimentos alimento4 = new Alimentos(4, "Ossinho", new BigDecimal("6"));
        return Arrays.asList(alimento, alimento2, alimento3, alimento4);

    }

    public static List<Pagamento> criarListaPagamento() {
        Pagamento pagamento = new Pagamento();
        return Arrays.asList(pagamento);
    }

    /**
     * ResponseVO higienizar(Cliente cliente, List<Animal> animais, Higiene higiene, String observacao);
     * Retornar o id do servico, o nome dele, o valor e a classe cliente
     */
    public ResponseVO higienizar(Clientes cliente, List<Animais> animais, Higiene higiene, String observacao) {
        ResponseVO response = new ResponseVO();
        for (int i = 0; i < animais.size(); i++) {
            if (higiene.equals(Higiene.BANHO)) {
                response.setValor(BigDecimal.valueOf(25));
                animais.get(i).setEstado(EstadoAnimal.LIMPO);
            } else if (higiene.equals(Higiene.TOSA)) {
                response.setValor(BigDecimal.valueOf(45));
                animais.get(i).setEstado(EstadoAnimal.TOSADO);
            } else if (higiene.equals(Higiene.BANHO_E_TOSA)) {
                response.setValor(BigDecimal.valueOf(65));
                animais.get(i).setEstado(EstadoAnimal.LIMPO_E_TOSADO);
            }
        }
        BigDecimal x = new BigDecimal(animais.size());
        response.setValor(response.getValor().multiply(x));

        response.setId(HIGIENIZAR);
        response.setClientes(cliente);
        response.setServicos(Servicos.HIGIENIZAR);
        return response;
    }

    /**
     * ResponseVO atendimentoClinico(Cliente cliente, List<Animal> animais, String observacao);
     * retornar resultado do atendimento no campo Observação do próprio animal além do id do servico, o nome dele, o valor e a classe cliente
     */
    public ResponseVO atendimentoClinico(Clientes cliente, List<Animais> animais, String observacao) {
        ResponseVO response = new ResponseVO();
        EsquemaVacinal esquemaVacinal = new EsquemaVacinal();
        for (int i = 0; i < animais.size(); i++) {
            Random random = new Random();
            int aleatorio = random.nextInt(4);
            if (animais.get(i).getVacinas().equals(aleatorio)) {
                System.out.println(animais.get(i).getNome() + " já vacinado!");
                break;
            }
            switch (aleatorio + 1) {
                case 1:
                    animais.get(i).setObservacoes(observacao = String.valueOf(Vacinas.VACINA_1));
                    break;
                case 2:
                    animais.get(i).setObservacoes(observacao = String.valueOf(Vacinas.VACINA_2));
                    break;
                case 3:
                    animais.get(i).setObservacoes(observacao = String.valueOf(Vacinas.VACINA_3));
                    break;
                case 4:
                    animais.get(i).setObservacoes(observacao = String.valueOf(Vacinas.VACINA_4));
                    break;
                case 5:
                    animais.get(i).setObservacoes(observacao = String.valueOf(Vacinas.VACINA_5));
                    break;
            }
        }
        response.setValor(BigDecimal.valueOf(110));
        BigDecimal x = new BigDecimal(animais.size());
        response.setValor(response.getValor().multiply(x));
        response.setId(ATENDIMENTO);
        response.setClientes(cliente);
        response.setServicos(Servicos.ATENDIMENTO_CLINICO);
        return response;
    }

    /**
     * ResponseVO vacinacao(Cliente cliente, List<Animal> animais, List<Vacinas> vacina, String observacao)
     * Só pode receber uma vacina por animal e deve retornar o id do servico, o nome dele, o valor e a classe cliente
     */
    public ResponseVO vacinacao(Clientes cliente, List<Animais> animais, List<Vacinas> vacinas, String observacao) {
        ResponseVO response = new ResponseVO();
        EsquemaVacinal esquemaVacinal = new EsquemaVacinal();
        for (int i = 0; i < animais.size(); i++) {
            animais.get(i).getVacinas().add(new EsquemaVacinal(LocalDate.parse("2023-01-23"), vacinas.get(i), "Vacina Tomada!!"));
        }
        response.setValor(BigDecimal.valueOf(45.25));
        BigDecimal x = new BigDecimal(animais.size());
        response.setValor(response.getValor().multiply(x));
        response.setId(VACINA);
        response.setClientes(cliente);
        response.setServicos(Servicos.VACINACAO);
        return response;
    }

    public void verAlimentos() {
        alimentoList.forEach(alimentos -> System.out.println(alimentos));
    }

    public void verRemedios() {
        remedioList.forEach(remedio -> System.out.println(remedio));
    }

    public void pagamento() {
        /** Inicialmente pensei em criar uma lista e adicionar nela os VOs
         * Aqui eu já teria o ID, Serviço e Valor dos serviços executados por 1 ou mais PETS
         * Tinha criado uma variavel para 'somar' esses valores do retorno do V
         * Mas, não deu muito certo :/
         *
         * Por fim, eu rodaria a lista já criada de Alimentos e Remedios,
         * pegaria um numero randomico, e acessaria de acordo com o número a linha com os registros.
         * Porém, não consegui pegar o campo Valor no construtor separado.
         *
         * Vi o que alguns colegas fizeram, mas como não consegui entender, achei mais honesto comigo mesma
         * enviar o trabalho sem a parte de Pagamento :/
         */

//
//        List listaPagamento = new ArrayList();
//        //Somar valores dos serviços realizados
//        BigDecimal valor_pagamento = new BigDecimal(listaPagamento);
//        valor_pagamento.add(response.getValor());
//        valor_pagamento.add(response2.getValor());
//        valor_pagamento.add(response3.getValor());
//
//        listaPagamento.add(1, response);
//        listaPagamento.add(2, response2);
//        listaPagamento.add(3, response3);
//        for (int i=0; i<listaPagamento.size();i++) {
//            System.out.println(listaPagamento);
//        }
//        System.out.println("Valor total a pagar: R$=" + valor_pagamento);
//
//
//        Somar valores de Alimentos e Remédios
//        for (int i = 0; i < response.getClientes().getPet().size(); i++) {
//            Random random = new Random();
//            int aleatorio = random.nextInt(3);
//            aleatorio++;
//            listaPagamento.add(remedioList.get(i).getId(aleatorio));
//            valor_pagamento.add(listaPagamento.get());
//            listaPagamento.add(alimentoList.get(i).getId(aleatorio));
//            System.out.println(listaPagamento);
//    }

    }
}
