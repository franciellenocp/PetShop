package Servicos;
import java.util.ArrayList;
import java.util.List;

public class Pagamento {
    //Atributos
    private List listaPagamento = new ArrayList<>();

    //Métodos

    public List getListaPagamento() {
        return listaPagamento;
    }

    public void setListaPagamento(List listaPagamento) {
        this.listaPagamento = listaPagamento;
    }

}
