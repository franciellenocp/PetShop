package Servicos;

public class Pagamento {

}
