package VO;

import Enums.EstadoAnimal;
import Enums.Higiene;
import Enums.Porte;
import Enums.Vacinas;
import Models.Animais;
import Models.Cachorro;
import Models.Clientes;
import Models.Gato;
import Servicos.EsquemaVacinal;
import Servicos.PetShop;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Teste {
    public static void main(String[] args) {
        //Construtor
        //Crie o objeto PetShop
        PetShop petShop = new PetShop();

        Clientes cliente = new Clientes();
        Clientes cliente2 = new Clientes();
        Clientes cliente3 = new Clientes();

        Cachorro cachorro = new Cachorro();
        Cachorro cachorro1 = new Cachorro();
        Gato gato = new Gato();
        Gato gato2 = new Gato();
        Gato gato3 = new Gato();

        EsquemaVacinal esquemaVacinal = new EsquemaVacinal();
        EsquemaVacinal esquemaVacinal2 = new EsquemaVacinal();
        EsquemaVacinal esquemaVacinal3 = new EsquemaVacinal();

        List<Animais> animais = new ArrayList<>();
        List<Animais> animais2 = new ArrayList<>();
        List<Animais> animais3 = new ArrayList<>();

        List<Vacinas> vacinas = new ArrayList<>();

        //cliente1 - 1 animal
        cliente.setId(1);
        cliente.setNome("Fran");
        cachorro.setNome("Mike");
        cachorro.setNascimento(LocalDate.parse("2018-04-23"));
        cachorro.setPorte(Porte.PEQUENO);
        cachorro.setPeso(9.5);
        cachorro.setEstado(EstadoAnimal.NORMAL);
        cachorro.setObservacoes("");
        animais.add(cachorro);
        cliente.setPet(animais);

        ResponseVO response_higienizar = petShop.higienizar(cliente, animais, Higiene.BANHO, null);
        System.out.println(response_higienizar);

        ResponseVO response_atendimentoClinico = petShop.atendimentoClinico(cliente, animais, cachorro.getObservacoes());
        System.out.println(response_atendimentoClinico);

        vacinas.add(Vacinas.valueOf(cachorro.getObservacoes()));
        System.out.println(vacinas);

        ResponseVO response_vacinacao = petShop.vacinacao(cliente, animais, vacinas, cachorro.getObservacoes());
        System.out.println(response_vacinacao);

        petShop.verRemedios();
        petShop.verAlimentos();


        //cliente2 - 2 animais
        cliente2.setId(2);
        cliente2.setNome("Kassia");

        gato.setNome("Videl");
        gato.setNascimento(LocalDate.parse("2020-08-03"));
        gato.setPorte(Porte.PEQUENO);
        gato.setPeso(3.5);
        gato.setEstado(EstadoAnimal.SUJO);
        gato.setObservacoes(" ");

        gato2.setNome("Garfield");
        gato2.setNascimento(LocalDate.parse("2019-01-03"));
        gato2.setPorte(Porte.PEQUENO);
        gato2.setPeso(5.5);
        gato2.setEstado(EstadoAnimal.NORMAL);
        gato2.setObservacoes(" ");

        animais2.add(gato);
        animais2.add(gato2);
        cliente2.setPet(animais2);

        ResponseVO response_higienizar2 = petShop.higienizar(cliente2, animais2, Higiene.BANHO_E_TOSA, null);
        System.out.println(response_higienizar2);

        //Colocar dentro de um vetor e validar as diferentes observações
        ResponseVO response_atendimentoClinico2 = petShop.atendimentoClinico(cliente, animais, cachorro.getObservacoes());
        System.out.println(response_atendimentoClinico2);

        //cliente3 - 3 animais
        cliente3.setId(3);
        cliente3.setNome("Yuri");

        cachorro1.setNome("Ice");
        cachorro1.setNascimento(LocalDate.parse("2017-01-13"));
        cachorro1.setPorte(Porte.MEDIO);
        cachorro1.setPeso(10.5);
        cachorro1.setEstado(EstadoAnimal.SUJO);
//      cachorro1.setVacinas(vacinas);
        cachorro1.setObservacoes(" ");

        gato3.setNome("Frajola");
        gato3.setNascimento(LocalDate.parse("2017-01-13"));
        gato3.setPorte(Porte.PEQUENO);
        gato3.setPeso(2.5);
        gato3.setEstado(EstadoAnimal.NORMAL);
//      gato3.setVacinas(vacinas);
        gato3.setObservacoes(" ");

        animais3.add(cachorro1);
        animais3.add(gato3);
        cliente3.setPet(animais2);

//        ResponseVO response3 = petShop.higienizar(cliente2, animais2, Higiene.TOSA, null);
//        System.out.println(response3);
    }
}
