package VO;

import Enums.EstadoAnimal;
import Enums.Higiene;
import Enums.Porte;
import Enums.Vacinas;
import Models.Animais;
import Models.Cachorro;
import Models.Clientes;
import Models.Gato;
import Servicos.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Teste {
    public static void main(String[] args) {
        //Construtor
        //Crie o objeto PetShop
        PetShop petShop = new PetShop();
        Pagamento pagamento = new Pagamento();

        Clientes cliente = new Clientes();
        Clientes cliente2 = new Clientes();
        Clientes cliente3 = new Clientes();

        Cachorro cachorro = new Cachorro();
        Cachorro cachorro1 = new Cachorro();
        Gato gato = new Gato();
        Gato gato2 = new Gato();
        Gato gato3 = new Gato();

        List<Animais> animais = new ArrayList<>();
        List<Animais> animais2 = new ArrayList<>();
        List<Animais> animais3 = new ArrayList<>();

        List<Vacinas> vacinas = new ArrayList<>();
        List<Vacinas> vacinas2 = new ArrayList<>();
        List<Vacinas> vacinas3 = new ArrayList<>();

        //cliente1 - 1 animal
        System.out.println("-------------------- UM CLIENTE E UM CACHORRO -----------------------------");

        cliente.setId(1);
        cliente.setNome("Fran");

        cachorro.setNome("Mike");
        cachorro.setNascimento(LocalDate.parse("2018-04-23"));
        cachorro.setPorte(Porte.PEQUENO);
        cachorro.setPeso(9.5);
        cachorro.setEstado(EstadoAnimal.NORMAL);
        cachorro.setObservacoes("");
        animais.add(cachorro);
        cliente.setPet(animais);

        ResponseVO response_higienizar = petShop.higienizar(cliente, animais, Higiene.BANHO, null);
        System.out.println(response_higienizar);

        ResponseVO response_atendimentoClinico = petShop.atendimentoClinico(cliente, animais, cachorro.getObservacoes());
        System.out.println(response_atendimentoClinico);

        vacinas.add(Vacinas.valueOf(cachorro.getObservacoes()));

        ResponseVO response_vacinacao = petShop.vacinacao(cliente, animais, vacinas, cachorro.getObservacoes());
        System.out.println(response_vacinacao);

        System.out.println("LISTA DE REMEDIOS:");
        petShop.verRemedios();
        System.out.println("LISTA DE ALIMENTOS:");
        petShop.verAlimentos();

        //A ideia era chamar Pagamento com os retornos dos VOs acima.
//        System.out.println("LISTA DE PAGAMENTOS:");
//        petShop.pagamento(response_vacinacao, response_higienizar,response_atendimentoClinico);

        //cliente2 - 2 animais
        System.out.println("-------------------- UM CLIENTE E DOIS GATOS -----------------------------");
        cliente2.setId(2);
        cliente2.setNome("Kassia");

        gato.setNome("Videl");
        gato.setNascimento(LocalDate.parse("2020-08-03"));
        gato.setPorte(Porte.PEQUENO);
        gato.setPeso(3.5);
        gato.setEstado(EstadoAnimal.SUJO);
        gato.setObservacoes(" ");

        gato2.setNome("Ice");
        gato2.setNascimento(LocalDate.parse("2019-01-03"));
        gato2.setPorte(Porte.PEQUENO);
        gato2.setPeso(5.5);
        gato2.setEstado(EstadoAnimal.SUJO);
        gato2.setObservacoes(" ");

        animais2.add(gato);
        animais2.add(gato2);
        cliente2.setPet(animais2);

        ResponseVO response_higienizar2 = petShop.higienizar(cliente2, animais2, Higiene.BANHO_E_TOSA, "Higienização");
        System.out.println(response_higienizar2);

        ResponseVO response_atendimentoClinico2 = petShop.atendimentoClinico(cliente2, animais2, "Atendimento Clinico");
        System.out.println(response_atendimentoClinico2);

        //Adicionar as observações do Atendimento na lista de 'Vacina' solicitadas
        for (int i = 0; i < animais2.size(); i++) {
            vacinas2.add(Vacinas.valueOf(animais2.get(i).getObservacoes()));
        }

        ResponseVO response_vacinacao2 = petShop.vacinacao(cliente2, animais2, vacinas2, "Vacinação");
        System.out.println(response_vacinacao2);

        System.out.println("LISTA DE REMEDIOS:");
        petShop.verRemedios();
        System.out.println("LISTA DE ALIMENTOS:");
        petShop.verAlimentos();

        //cliente3 - 3 animais
        System.out.println("-------------------- UM CLIENTE UM CACHORRO E UM GATO ---------------------");
        cliente3.setId(3);
        cliente3.setNome("Thalles");

        cachorro1.setNome("Amora");
        cachorro1.setNascimento(LocalDate.parse("2017-01-13"));
        cachorro1.setPorte(Porte.MEDIO);
        cachorro1.setPeso(10.5);
        cachorro1.setEstado(EstadoAnimal.SUJO);
        cachorro1.setObservacoes(" ");

        gato3.setNome("Frajola");
        gato3.setNascimento(LocalDate.parse("2017-01-13"));
        gato3.setPorte(Porte.PEQUENO);
        gato3.setPeso(2.5);
        gato3.setEstado(EstadoAnimal.NORMAL);
        gato3.setObservacoes(" ");

        animais3.add(cachorro1);
        animais3.add(gato3);
        cliente3.setPet(animais2);

        ResponseVO response_higienizar3 = petShop.higienizar(cliente3, animais3, Higiene.TOSA, "Higienização");
        System.out.println(response_higienizar3);

        ResponseVO response_atendimentoClinico3 = petShop.atendimentoClinico(cliente3, animais3, "Atendimento Clinico");
        System.out.println(response_atendimentoClinico3);

        //Adicionar as observações do Atendimento na lista de 'Vacina' solicitadas
        for (int i = 0; i < animais3.size(); i++) {
            vacinas3.add(Vacinas.valueOf(animais3.get(i).getObservacoes()));
        }

        ResponseVO response_vacinacao3 = petShop.vacinacao(cliente3, animais3, vacinas3, "Vacinação");
        System.out.println(response_vacinacao3);

        System.out.println("LISTA DE REMEDIOS:");
        petShop.verRemedios();
        System.out.println("LISTA DE ALIMENTOS:");
        petShop.verAlimentos();

    }
}
