package VO;

import Enums.Servicos;
import Models.Clientes;

import java.math.BigDecimal;

public class ResponseVO {
    //Atributos
    private int id;
    private Servicos servicos;
    private BigDecimal valor;
    private Clientes clientes;

    //Construtor
    public ResponseVO(int id, Servicos servicos, BigDecimal valor, Clientes clientes) {
        this.id = id;
        this.servicos = servicos;
        this.valor = valor;
        this.clientes = clientes;
    }

    public ResponseVO() {
    }

    //Metodos

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Servicos getServicos() {
        return servicos;
    }

    public void setServicos(Servicos servicos) {
        this.servicos = servicos;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public Clientes getClientes() {
        return clientes;
    }

    public void setClientes(Clientes clientes) {
        this.clientes = clientes;
    }

    @Override
    public String toString() {
        return "ResponseVO{" +
                "id=" + id +
                ", servicos=" + servicos +
                ", valor=" + valor +
                ", clientes=" + clientes +
                '}';
    }
}
